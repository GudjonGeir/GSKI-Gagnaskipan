#include "PrefixStringSet.h"

PrefixStringSet::PrefixStringSet()
{
    root = new TrieNode();
}

PrefixStringSet::~PrefixStringSet()
{
    remove_all(root);
}

bool PrefixStringSet::insert(string s)
{
    // TODO: Implement
}

void PrefixStringSet::remove(string s)
{
    // OPTIONAL
}

bool PrefixStringSet::contains(string s)
{
    // OPTIONAL
}

void PrefixStringSet::remove_all(NodePtr node)
{
    // TODO: Implement
}
