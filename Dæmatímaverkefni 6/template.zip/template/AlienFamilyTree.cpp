#include "AlienFamilyTree.h"

AlienFamilyTree::AlienFamilyTree()
{
    head = NULL;
}

AlienFamilyTree::~AlienFamilyTree()
{
    delete_tree(head);
    head = NULL;
}

bool AlienFamilyTree::is_descendant(string name)
{
    // TODO: Implement
}

bool AlienFamilyTree::is_descendant(string ancestor, string descendant)
{
    // TODO: Implement
}

int AlienFamilyTree::generation(string name)
{
    // TODO: Implement
}

NodePtr AlienFamilyTree::find(NodePtr root, string name)
{
    // TODO: Implement
}

// int AlienFamilyTree::generation(NodePtr root, string name, int gen)
// {
//      Optionally implement
// }

void AlienFamilyTree::delete_tree(NodePtr root)
{
    //TODO: Implement
}

// Helper function that reads a binary tree in from the specified input stream
// and returns the root of the tree.
NodePtr parse_tree(istream& ins)
{
    char c;
    ins >> c; // Read (

    ins >> c; // Read next character

    // If the next character is ), this is the empty tree
    if(c == ')') {
        return NULL;
    }

    // Return the "borrowed" character to the input stream
    ins.putback(c);

    string node_data;
    ins >> node_data;

    NodePtr node = new BinaryStringNode;
    node->data = node_data;
    node->left = parse_tree(ins);
    node->right = parse_tree(ins);

    ins >> c; // Consume the trailing )

    return node;
}

void indent(ostream& outs, int level)
{
    for(int i = 0; i != level * 3; i++) {
        outs << " ";
    }
}

// Helper function that prints the binary tree root to the specified output
// stream.
void print_tree(ostream& outs, NodePtr root, int level = 0)
{
    indent(outs, level);
    if(root == NULL) {
        outs << "()" << endl;
        return;
    }
    outs << "(" << root->data << endl;
    print_tree(outs, root->left, level + 1);
    print_tree(outs, root->right, level + 1);
    indent(outs, level);
    outs << ")" << endl;
}

istream& operator>> (istream& ins, AlienFamilyTree& tree)
{
    tree.head = parse_tree(ins);
    return ins;
}

ostream& operator<< (ostream& outs, const AlienFamilyTree& tree)
{
    print_tree(outs, tree.head);
    return outs;
}

